﻿using System;
using System.Collections.Generic;

using System.Text;

//namespace Model
//{
//   public class size
//    {
//       private int _id;
//       public int id
//       {
//           get { return _id; }
//           set { _id = value; }
//       }
//       private string  _sizeid;
//       public string    sizeid
//       {
//           get { return _sizeid; }
//           set { _sizeid = value; }
//       }
//       private string _sizename;
//       public string sizename
//       {
//           get { return _sizename; }
//           set { _sizename = value; }
//       }
          
           
//    }
//}
