﻿using System;
using System.Collections.Generic;

using System.Text;

namespace Model
{
   public  class fathercate

    {
       private int _fathercateid;
       public int fathercateid
       {
           get { return _fathercateid; }
           set { _fathercateid = value; }
       }
       private string _fathername;
       public string fathername
   {
       get { return _fathername; }
       set { _fathername = value; }

   }
    }
}
